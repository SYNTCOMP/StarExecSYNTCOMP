.. cmake-module:: ../../Modules/FindPython3.cmake

.. cmake-module:: ../../Modules/FindGettext.cmake

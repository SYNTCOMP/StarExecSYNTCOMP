CTEST_INTERACTIVE_DEBUG_MODE
----------------------------

.. include:: ENV_VAR.txt

Environment variable that will exist and be set to ``1`` when a test executed
by CTest is run in interactive mode.
